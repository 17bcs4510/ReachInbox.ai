import * as msal from '@azure/msal-node';

const MSAL_CONFIG = {
  auth: {
    clientId: process.env.OUTLOOK_CLIENT_ID!,
    authority: `https://login.microsoftonline.com/${process.env.OUTLOOK_TENANT_ID}`,
    clientSecret: process.env.OUTLOOK_CLIENT_SECRET,
  }
};

const SCOPES = ["https://graph.microsoft.com/.default"];

export const msalClient = new msal.ConfidentialClientApplication(MSAL_CONFIG);

export const authenticateOutlook = async () => {
  const authUrl = msalClient.getAuthCodeUrl({
    scopes: SCOPES,
    redirectUri: process.env.OUTLOOK_REDIRECT_URI,
  });

  return authUrl;
};

export const getOutlookAuthToken = async (code: string) => {
  const tokenRequest = {
    code,
    scopes: SCOPES,
    redirectUri: process.env.OUTLOOK_REDIRECT_URI,
  };

  const { accessToken } = await msalClient.acquireTokenByCode(tokenRequest);
  return accessToken;
};
