import nodemailer from 'nodemailer';

export const sendResponse = async (email: any, label: string) => {
  let responseText = '';

  switch (label) {
    case 'Interested':
      responseText = 'Thank you for your interest! When would you be available for a demo call?';
      break;
    case 'Not Interested':
      responseText = 'Thank you for your time. If you change your mind, feel free to reach out!';
      break;
    case 'More Information':
      responseText = 'Could you please specify what more information you are looking for?';
      break;
  }

  const transporter = nodemailer.createTransport({
    service: 'gmail', // or Outlook, depending on your requirements
    auth: {
      user: process.env.EMAIL_USER!,
      pass: process.env.EMAIL_PASS!,
    },
  });

  const mailOptions = {
    from: process.env.EMAIL_USER!,
    to: email.from,
    subject: 'Re: ' + email.subject,
    text: responseText,
  };

  await transporter.sendMail(mailOptions  
