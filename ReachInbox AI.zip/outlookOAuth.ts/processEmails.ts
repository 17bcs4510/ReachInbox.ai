import { Configuration, OpenAIApi } from 'openai';

const openai = new OpenAIApi(
  new Configuration({ apiKey: process.env.OPENAI_API_KEY })
);

export const classifyEmail = async (emailContent: string) => {
  const prompt = `Classify the following email content into categories: Interested, Not Interested, More Information.\n\n"${emailContent}"`;
  const response = await openai.createCompletion({
    model: 'text-davinci-003',
    prompt,
    max_tokens: 60,
  });

  return response.data.choices[0].text.trim();
};
